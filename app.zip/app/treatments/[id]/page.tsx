'use client'

import { useEffect, useState } from 'react'
import { useParams, useRouter } from 'next/navigation'
import { useAuth } from '@/app/lib/auth'
import {
  useTreatmentById,
  useFavoriteTreatments,
  useTreatmentFromRecentAnalysis,
  useToggleFavoriteTreatment,
} from '@/app/lib/data'
import { useToast } from '@/app/hooks/useToast'
import {
  ArrowLeft,
  Clock,
  DollarSign,
  AlertCircle,
  Heart,
  Sparkles,
  TrendingUp,
} from 'lucide-react'
import Link from 'next/link'
import { LoadingSpinner } from '@/app/lib/ui'
import Button from '@/app/components/ui/Button'
import Card from '@/app/components/ui/Card'

interface Treatment {
  id: string
  name: string
  description: string
  benefits: string
  cost: number
  recovery_time: string
  risk_level: string
  duration_minutes: number
}

export default function TreatmentDetailPage() {
  const params = useParams()
  const router = useRouter()
  const { user } = useAuth()
  const treatmentId = params.id as string

  const { data: treatment, isLoading: treatmentLoading } = useTreatmentById(treatmentId)
  const { data: favorites = [] } = useFavoriteTreatments()
  const { data: analysisInfo } = useTreatmentFromRecentAnalysis(treatmentId)
  const { toggleFavorite, isPending: isToggling } = useToggleFavoriteTreatment()
  const toast = useToast()

  const isFavorite = favorites.includes(treatmentId)

  const handleToggleFavorite = async () => {
    if (!user) {
      toast.error('로그인이 필요합니다.')
      router.push('/auth/login')
      return
    }

    try {
      await toggleFavorite(treatmentId)
      toast.success(
        isFavorite ? '관심 시술에서 제거되었습니다.' : '관심 시술로 등록되었습니다.'
      )
    } catch (error: any) {
      toast.error(error.message || '오류가 발생했습니다.')
    }
  }

  if (treatmentLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <LoadingSpinner fullScreen message="로딩 중..." />
      </div>
    )
  }

  if (!treatment) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-pink-50 via-white to-purple-50">
        <div className="text-center">
          <p className="text-gray-600 mb-4">시술 정보를 찾을 수 없습니다.</p>
          <Link
            href="/home"
            className="text-pink-600 hover:text-pink-700 font-semibold"
          >
            홈으로 돌아가기
          </Link>
        </div>
      </div>
    )
  }

  const treatmentData = treatment as Treatment

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 via-white to-purple-50 pb-20">
      <div className="max-w-4xl mx-auto px-4 py-8">
        <Link
          href="/home"
          className="inline-flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-6"
        >
          <ArrowLeft className="w-5 h-5" />
          뒤로가기
        </Link>

        <div className="bg-white rounded-2xl shadow-xl p-8 space-y-6">
          {/* 헤더 */}
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <h1 className="text-4xl font-bold text-gray-900 mb-2">
                {treatmentData.name}
              </h1>
              {analysisInfo?.treatment && (
                <div className="flex items-center gap-2 mt-2">
                  <Sparkles className="w-4 h-4 text-pink-500" />
                  <span className="text-sm text-pink-600 font-medium">
                    AI 추천 시술
                  </span>
                  {analysisInfo.treatment.score && (
                    <span className="text-xs text-gray-500">
                      (적합도 {Math.round(analysisInfo.treatment.score * 100)}%)
                    </span>
                  )}
                </div>
              )}
            </div>
            <button
              onClick={handleToggleFavorite}
              disabled={isToggling || !user}
              className={`p-3 rounded-xl transition-all ${
                isFavorite
                  ? 'bg-pink-100 text-pink-600 hover:bg-pink-200'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              } disabled:opacity-50 disabled:cursor-not-allowed`}
              aria-label={isFavorite ? '관심 시술 해제' : '관심 시술 등록'}
            >
              <Heart
                className={`w-6 h-6 ${isFavorite ? 'fill-current' : ''}`}
              />
            </button>
          </div>

          {/* AI 생성 설명 (NLG 결과) */}
          {analysisInfo?.nlg && (
            <Card className="bg-gradient-to-r from-pink-50 to-purple-50 border-pink-200">
              <div className="flex items-start gap-3 mb-3">
                <Sparkles className="w-5 h-5 text-pink-600 flex-shrink-0 mt-0.5" />
                <div className="flex-1">
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">
                    AI 맞춤 설명
                  </h3>
                  {analysisInfo.nlg.headline && (
                    <p className="text-base font-medium text-gray-800 mb-2">
                      {analysisInfo.nlg.headline}
                    </p>
                  )}
                  {analysisInfo.nlg.paragraphs && (
                    <div className="space-y-2">
                      {analysisInfo.nlg.paragraphs.map((paragraph: string, idx: number) => (
                        <p key={idx} className="text-sm text-gray-700 leading-relaxed">
                          {paragraph}
                        </p>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </Card>
          )}

          {/* 기본 설명 */}
          <div className="prose max-w-none">
            <p className="text-lg text-gray-700 leading-relaxed">
              {treatmentData.description}
            </p>
          </div>

          {/* 시술 정보 그리드 */}
          <div className="grid md:grid-cols-2 gap-6">
            {/* 효과 */}
            <Card className="bg-pink-50">
              <div className="flex items-center gap-2 mb-4">
                <TrendingUp className="w-5 h-5 text-pink-600" />
                <h3 className="text-lg font-semibold text-gray-900">효과</h3>
              </div>
              <p className="text-gray-700">{treatmentData.benefits}</p>
            </Card>

            {/* 상세 정보 */}
            <div className="space-y-4">
              <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-xl">
                <DollarSign className="w-5 h-5 text-gray-600 flex-shrink-0" />
                <div className="flex-1">
                  <p className="text-sm text-gray-600">예상 비용</p>
                  <p className="text-lg font-semibold text-gray-900">
                    {treatmentData.cost
                      ? `${treatmentData.cost.toLocaleString()}원`
                      : '상담 후 결정'}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-xl">
                <Clock className="w-5 h-5 text-gray-600 flex-shrink-0" />
                <div className="flex-1">
                  <p className="text-sm text-gray-600">소요 시간</p>
                  <p className="text-lg font-semibold text-gray-900">
                    약 {treatmentData.duration_minutes}분
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-xl">
                <AlertCircle className="w-5 h-5 text-gray-600 flex-shrink-0" />
                <div className="flex-1">
                  <p className="text-sm text-gray-600">회복 기간</p>
                  <p className="text-lg font-semibold text-gray-900">
                    {treatmentData.recovery_time}
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* 예상 개선률 (분석 결과에서) */}
          {analysisInfo?.treatment?.expected_improvement_pct && (
            <Card className="bg-blue-50 border-blue-200">
              <div className="flex items-center gap-3">
                <TrendingUp className="w-5 h-5 text-blue-600" />
                <div className="flex-1">
                  <p className="text-sm text-blue-600 font-medium mb-1">
                    예상 개선률
                  </p>
                  <p className="text-2xl font-bold text-blue-900">
                    {Math.round(analysisInfo.treatment.expected_improvement_pct * 100)}%
                  </p>
                  <p className="text-xs text-blue-700 mt-1">
                    * 개인 피부 상태에 따라 결과가 달라질 수 있습니다.
                  </p>
                </div>
              </div>
            </Card>
          )}

          {/* 주의사항 */}
          <Card className="bg-yellow-50 border-yellow-200">
            <div className="flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-yellow-600 mt-0.5 flex-shrink-0" />
              <div className="flex-1">
                <p className="font-semibold text-yellow-900 mb-1">주의사항</p>
                <p className="text-sm text-yellow-800 mb-2">
                  위험도: {treatmentData.risk_level} | 시술 전 전문의 상담을 권장합니다.
                  본 정보는 참고용이며, 실제 시술은 전문의와 상담하시기 바랍니다.
                </p>
                <p className="text-xs text-yellow-700">
                  본 서비스는 의료행위 또는 전문적 진단을 대체하지 않습니다. AI 분석 결과는
                  참고용 정보이며, 정확한 진단이나 치료를 위해서는 반드시 전문 의료인의 상담이
                  필요합니다.
                </p>
              </div>
            </div>
          </Card>

          {/* 관련 후기 (향후 확장) */}
          <Card>
            <h3 className="text-lg font-semibold text-gray-900 mb-4">관련 후기</h3>
            <p className="text-gray-600 text-sm">
              후기 기능은 곧 추가될 예정입니다.
            </p>
          </Card>

          {/* CTA 버튼 */}
          <div className="flex gap-4 pt-4">
            <Button
              variant="outline"
              onClick={() => router.push('/home')}
              className="flex-1"
            >
              홈으로
            </Button>
            <Button
              variant="primary"
              onClick={() => router.push('/analyze')}
              className="flex-1"
            >
              내 피부 분석하기
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
