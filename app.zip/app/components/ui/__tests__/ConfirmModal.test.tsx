/**
 * ConfirmModal 컴포넌트 테스트
 */

import { render, screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { ConfirmModal } from '../ConfirmModal'

// Mock Modal component
jest.mock('../Modal', () => ({
  __esModule: true,
  default: ({ isOpen, onClose, title, children }: any) => {
    if (!isOpen) return null
    return (
      <div role="dialog" aria-modal="true" aria-labelledby="modal-title">
        {title && <h2 id="modal-title">{title}</h2>}
        <button onClick={onClose} aria-label="모달 닫기">
          닫기
        </button>
        {children}
      </div>
    )
  },
}))

const defaultProps = {
  isOpen: true,
  onClose: jest.fn(),
  onConfirm: jest.fn(),
  title: '확인 모달',
  message: '이 작업을 진행하시겠습니까?',
}

describe('ConfirmModal', () => {
  beforeEach(() => {
    jest.clearAllMocks()
  })

  describe('기본 렌더링', () => {
    it('모달이 열려있을 때 내용이 표시되어야 함', () => {
      render(<ConfirmModal {...defaultProps} />)

      expect(screen.getByText('확인 모달')).toBeInTheDocument()
      expect(screen.getByText('이 작업을 진행하시겠습니까?')).toBeInTheDocument()
    })

    it('모달이 닫혀있을 때 내용이 표시되지 않아야 함', () => {
      render(<ConfirmModal {...defaultProps} isOpen={false} />)

      expect(screen.queryByText('확인 모달')).not.toBeInTheDocument()
    })

    it('기본 확인/취소 버튼 텍스트가 표시되어야 함', () => {
      render(<ConfirmModal {...defaultProps} />)

      expect(screen.getByText('확인')).toBeInTheDocument()
      expect(screen.getByText('취소')).toBeInTheDocument()
    })

    it('커스텀 확인/취소 버튼 텍스트가 표시되어야 함', () => {
      render(
        <ConfirmModal
          {...defaultProps}
          confirmText="삭제"
          cancelText="닫기"
        />
      )

      expect(screen.getByText('삭제')).toBeInTheDocument()
      expect(screen.getByText('닫기')).toBeInTheDocument()
    })
  })

  describe('버튼 동작', () => {
    it('취소 버튼 클릭 시 onClose가 호출되어야 함', async () => {
      const user = userEvent.setup()
      const onClose = jest.fn()
      render(<ConfirmModal {...defaultProps} onClose={onClose} />)

      const cancelButton = screen.getByText('취소')
      await user.click(cancelButton)

      expect(onClose).toHaveBeenCalledTimes(1)
    })

    it('확인 버튼 클릭 시 onConfirm이 호출되어야 함', async () => {
      const user = userEvent.setup()
      const onConfirm = jest.fn()
      render(<ConfirmModal {...defaultProps} onConfirm={onConfirm} />)

      const confirmButton = screen.getByText('확인')
      await user.click(confirmButton)

      expect(onConfirm).toHaveBeenCalledTimes(1)
    })

    it('onConfirm이 Promise를 반환할 때 처리되어야 함', async () => {
      const user = userEvent.setup()
      const onConfirm = jest.fn().mockResolvedValue(undefined)
      render(<ConfirmModal {...defaultProps} onConfirm={onConfirm} />)

      const confirmButton = screen.getByText('확인')
      await user.click(confirmButton)

      await waitFor(() => {
        expect(onConfirm).toHaveBeenCalledTimes(1)
      })
    })
  })

  describe('variant', () => {
    it('기본 variant는 primary여야 함', () => {
      render(<ConfirmModal {...defaultProps} />)

      const confirmButton = screen.getByText('확인')
      // Button 컴포넌트의 variant prop 확인은 실제 구현에 따라 다를 수 있음
      expect(confirmButton).toBeInTheDocument()
    })

    it('danger variant가 적용되어야 함', () => {
      render(<ConfirmModal {...defaultProps} confirmVariant="danger" />)

      const confirmButton = screen.getByText('확인')
      expect(confirmButton).toBeInTheDocument()
    })
  })

  describe('로딩 상태', () => {
    it('isLoading이 true일 때 확인 버튼이 비활성화되어야 함', () => {
      render(<ConfirmModal {...defaultProps} isLoading={true} />)

      const confirmButton = screen.getByText('확인')
      expect(confirmButton).toBeDisabled()
    })

    it('isLoading이 true일 때 취소 버튼이 비활성화되어야 함', () => {
      render(<ConfirmModal {...defaultProps} isLoading={true} />)

      const cancelButton = screen.getByText('취소')
      expect(cancelButton).toBeDisabled()
    })

    it('isLoading이 true일 때 닫기 버튼이 표시되지 않아야 함', () => {
      render(<ConfirmModal {...defaultProps} isLoading={true} />)

      // Modal의 showCloseButton이 false가 되어야 함
      // 실제 구현에 따라 다를 수 있음
      expect(screen.queryByLabelText('모달 닫기')).not.toBeInTheDocument()
    })
  })

  describe('접근성', () => {
    it('role="dialog"가 있어야 함', () => {
      render(<ConfirmModal {...defaultProps} />)

      const dialog = screen.getByRole('dialog')
      expect(dialog).toBeInTheDocument()
    })

    it('aria-modal="true"가 있어야 함', () => {
      render(<ConfirmModal {...defaultProps} />)

      const dialog = screen.getByRole('dialog')
      expect(dialog).toHaveAttribute('aria-modal', 'true')
    })

    it('제목이 aria-labelledby로 연결되어야 함', () => {
      render(<ConfirmModal {...defaultProps} />)

      const dialog = screen.getByRole('dialog')
      const title = screen.getByText('확인 모달')
      expect(title).toHaveAttribute('id', 'modal-title')
      expect(dialog).toHaveAttribute('aria-labelledby', 'modal-title')
    })
  })
})


