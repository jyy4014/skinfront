'use client'

import { History, TrendingUp, TrendingDown, Minus } from 'lucide-react'
import Link from 'next/link'
import { designTokens } from '@/app/styles/design-tokens'
import { useMemo } from 'react'

interface RecentAnalysisCardProps {
  analysis: {
    id: string
    image_url: string
    result_summary: string
    created_at: string
    skin_condition_scores?: Record<string, number>
    previousScores?: Record<string, number>
  }
}

export default function RecentAnalysisCard({ analysis }: RecentAnalysisCardProps) {
  const mainScore = useMemo(() => {
    if (!analysis.skin_condition_scores) return null
    
    const scores = Object.values(analysis.skin_condition_scores)
    if (scores.length === 0) return null
    
    const avg = scores.reduce((a, b) => a + b, 0) / scores.length
    return Math.round(avg * 100)
  }, [analysis.skin_condition_scores])

  const trend = useMemo(() => {
    if (!analysis.skin_condition_scores || !analysis.previousScores) return null
    
    const currentAvg = Object.values(analysis.skin_condition_scores).reduce((a, b) => a + b, 0) / Object.values(analysis.skin_condition_scores).length
    const previousAvg = Object.values(analysis.previousScores).reduce((a, b) => a + b, 0) / Object.values(analysis.previousScores).length
    
    const diff = currentAvg - previousAvg
    if (Math.abs(diff) < 0.05) return { type: 'neutral', value: 0 }
    if (diff > 0) return { type: 'up', value: Math.round(diff * 100) }
    return { type: 'down', value: Math.round(Math.abs(diff) * 100) }
  }, [analysis.skin_condition_scores, analysis.previousScores])

  const topIssues = useMemo(() => {
    if (!analysis.skin_condition_scores) return []
    
    return Object.entries(analysis.skin_condition_scores)
      .sort(([, a], [, b]) => b - a)
      .slice(0, 3)
      .map(([label, score]) => ({
        label: label.replace('_', ' '),
        score: Math.round(score * 100),
      }))
  }, [analysis.skin_condition_scores])

  return (
    <div 
      className="rounded-2xl p-5 shadow-lg"
      style={{
        backgroundColor: designTokens.colors.surface.base,
        border: `1px solid ${designTokens.colors.border.subtle}`,
      }}
    >
      <div className="flex items-center gap-2 mb-4">
        <History className="w-5 h-5" style={{ color: designTokens.colors.gray[600] }} />
        <h3 className="text-lg font-semibold" style={{ color: designTokens.colors.text.primary }}>
          최근 분석 결과
        </h3>
      </div>

      <Link 
        href={`/analysis/${analysis.id}`}
        className="focus:outline-none focus:ring-2 focus:ring-pink-500 focus:ring-offset-2 rounded-xl block"
        aria-label={`최근 분석 결과 보기: ${analysis.result_summary}`}
      >
        <div className="flex gap-4 active:scale-[0.98] transition-transform">
          {/* 이미지 썸네일 */}
          <div className="relative w-24 h-24 rounded-xl overflow-hidden bg-gray-100 flex-shrink-0">
            <img
              src={analysis.image_url}
              alt="분석 이미지"
              className="w-full h-full object-cover"
            />
            {mainScore !== null && (
              <div 
                className="absolute top-2 right-2 px-2 py-1 rounded-lg text-xs font-bold text-white shadow-lg"
                style={{
                  backgroundColor: mainScore >= 70 ? designTokens.colors.success[500] : 
                                  mainScore >= 50 ? designTokens.colors.warning[500] : 
                                  designTokens.colors.danger[500],
                }}
              >
                {mainScore}점
              </div>
            )}
          </div>

          {/* 내용 */}
          <div className="flex-1 min-w-0">
            <p 
              className="mb-2 line-clamp-2 text-sm leading-relaxed"
              style={{ color: designTokens.colors.text.primary }}
            >
              {analysis.result_summary}
            </p>
            
            {/* 주요 지표 */}
            {topIssues.length > 0 && (
              <div className="flex flex-wrap gap-2 mb-2">
                {topIssues.map((issue, idx) => (
                  <span
                    key={idx}
                    className="px-2 py-1 rounded-md text-xs font-medium"
                    style={{
                      backgroundColor: designTokens.colors.gray[100],
                      color: designTokens.colors.text.secondary,
                    }}
                  >
                    {issue.label} {issue.score}%
                  </span>
                ))}
              </div>
            )}

            {/* 트렌드 */}
            {trend && (
              <div className="flex items-center gap-1 mb-2">
                {trend.type === 'up' && (
                  <>
                    <TrendingUp className="w-4 h-4" style={{ color: designTokens.colors.success[500] }} />
                    <span className="text-xs" style={{ color: designTokens.colors.success[600] }}>
                      {trend.value}% 개선
                    </span>
                  </>
                )}
                {trend.type === 'down' && (
                  <>
                    <TrendingDown className="w-4 h-4" style={{ color: designTokens.colors.danger[500] }} />
                    <span className="text-xs" style={{ color: designTokens.colors.danger[600] }}>
                      {trend.value}% 악화
                    </span>
                  </>
                )}
                {trend.type === 'neutral' && (
                  <>
                    <Minus className="w-4 h-4" style={{ color: designTokens.colors.gray[500] }} />
                    <span className="text-xs" style={{ color: designTokens.colors.text.secondary }}>
                      변화 없음
                    </span>
                  </>
                )}
              </div>
            )}

            <p 
              className="text-xs mb-2"
              style={{ color: designTokens.colors.text.tertiary }}
            >
              {new Date(analysis.created_at).toLocaleDateString('ko-KR')}
            </p>
            
            <span 
              className="text-sm font-medium inline-block"
              style={{ color: designTokens.colors.primary[600] }}
              aria-hidden="true"
            >
              자세히 보기 →
            </span>
          </div>
        </div>
      </Link>
    </div>
  )
}


