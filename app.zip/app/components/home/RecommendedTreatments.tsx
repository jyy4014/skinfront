'use client'

import Link from 'next/link'
import { designTokens } from '@/app/styles/design-tokens'
import { useRecommendedTreatments } from '@/app/lib/data/queries/treatment'

interface Treatment {
  id: string
  name: string
  description: string
}

export default function RecommendedTreatments() {
  const { data: treatments = [], isLoading: loading } = useRecommendedTreatments()

  if (loading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {[1, 2, 3].map((i) => (
          <div key={i} className={`p-4 border-2 border-[color:var(--color-border-strong)] rounded-[var(--radius-lg)] animate-pulse`}>
            <div className={`h-4 bg-[color:var(--color-gray-200)] rounded-[var(--radius-sm)] mb-2`}></div>
            <div className={`h-3 bg-[color:var(--color-gray-200)] rounded-[var(--radius-sm)]`}></div>
          </div>
        ))}
      </div>
    )
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      {treatments.map((treatment) => (
        <Link
          key={treatment.id}
          href={`/treatments/${treatment.id}`}
          className={`p-4 border-2 border-[color:var(--color-border-strong)] rounded-[var(--radius-lg)] hover:border-[color:var(--color-primary-500)] hover:shadow-[var(--shadow-soft)] transition-all`}
        >
          <h4 className={`font-semibold text-[color:var(--color-text-primary)] mb-1`}>{treatment.name}</h4>
          <p className={`text-sm text-[color:var(--color-text-secondary)]`}>
            {treatment.description || '피부 개선에 도움이 됩니다'}
          </p>
        </Link>
      ))}
    </div>
  )
}

