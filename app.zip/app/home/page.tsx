'use client'

import { useMemo } from 'react'
import RecommendedTreatments from '@/app/components/home/RecommendedTreatments'
import BottomNav from '@/app/components/common/BottomNav'
import { PermissionChecker } from '@/app/components/common/PermissionChecker'
import ProfileCompletionBanner from '@/app/components/profile/ProfileCompletionBanner'
import GreetingHeader from '@/app/components/home/GreetingHeader'
import DailyAnalysisCTA from '@/app/components/home/DailyAnalysisCTA'
import RecentAnalysisCard from '@/app/components/home/RecentAnalysisCard'
import SkinSummaryCard from '@/app/components/home/SkinSummaryCard'
import { useAnalysisHistory, useUserProfile } from '@/app/lib/data'
import { useAuth } from '@/app/lib/auth'
import { LoadingSpinner } from '@/app/lib/ui'
import { designTokens } from '@/app/styles/design-tokens'

export default function HomePage() {
  // 사용자 정보 조회 (통합 인증 모듈 사용)
  const { user, loading: authLoading } = useAuth()
  
  // 사용자 프로필 조회 (별명 포함) - user를 전달하여 중복 호출 방지
  const { data: userProfile, isLoading: profileLoading } = useUserProfile({
    user, // useAuth의 user를 전달하여 중복 getUser() 호출 방지
    enabled: !!user && !authLoading,
  })

  // 최근 분석 결과 조회 - 최근 3개 (요약용) - user를 전달하여 중복 호출 방지
  const { data: analyses, isLoading } = useAnalysisHistory({
    user, // useAuth의 user를 전달하여 중복 getUser() 호출 방지
    filters: { limit: 3 },
    enabled: !!user && !authLoading,
  })

  // 최근 분석 결과 (1개)
  const recentAnalysis = analyses && analyses.length > 0 ? analyses[0] : null

  // 별명 우선, 없으면 이름 사용
  const displayName = 
    userProfile?.profile?.nickname || 
    userProfile?.profile?.name || 
    userProfile?.user_metadata?.nickname || 
    userProfile?.user_metadata?.name || 
    null

  // 오늘의 분석 횟수 계산
  const todayAnalysisCount = useMemo(() => {
    if (!analyses) return 0
    
    const today = new Date()
    today.setHours(0, 0, 0, 0)
    
    return analyses.filter((analysis: any) => {
      const analysisDate = new Date(analysis.created_at)
      analysisDate.setHours(0, 0, 0, 0)
      return analysisDate.getTime() === today.getTime()
    }).length
  }, [analyses])

  // 인증 로딩 중일 때만 로딩 표시
  if (authLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <LoadingSpinner fullScreen message="로딩 중..." />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 via-pink-50 to-purple-50 pb-20">
      {/* 권한 확인 컴포넌트 - 앱 시작 시 카메라 권한 확인 */}
      <PermissionChecker />
      
      {/* Header - 모바일 앱 스타일 */}
      <header 
        className="bg-white/80 backdrop-blur-lg sticky top-0 z-40 safe-area-top border-b"
        style={{
          borderColor: designTokens.colors.border.subtle,
        }}
      >
        <div className="max-w-md mx-auto px-4 py-3">
          <GreetingHeader displayName={displayName} />
        </div>
      </header>

      <main className="max-w-md mx-auto px-4 py-6 space-y-6">
        {/* 프로필 완성 배너 - userProfile을 props로 전달하여 중복 호출 방지 */}
        <ProfileCompletionBanner userProfile={userProfile} />

        {/* 오늘의 분석 CTA */}
        <DailyAnalysisCTA 
          lastAnalysisDate={recentAnalysis?.created_at}
          todayAnalysisCount={todayAnalysisCount}
        />

        {/* 피부 상태 요약 */}
        {analyses && analyses.length > 0 && (
          <SkinSummaryCard analyses={analyses} />
        )}

        {/* 최근 분석 결과 */}
        {recentAnalysis && (
          <RecentAnalysisCard 
            analysis={{
              ...recentAnalysis,
              previousScores: analyses && analyses.length > 1 
                ? analyses[1].skin_condition_scores 
                : undefined,
            }}
          />
        )}

        {/* Recommended Treatments */}
        <div 
          className="rounded-2xl p-5 shadow-lg"
          style={{
            backgroundColor: designTokens.colors.surface.base,
            border: `1px solid ${designTokens.colors.border.subtle}`,
          }}
        >
          <h3 
            className="text-lg font-semibold mb-4"
            style={{ color: designTokens.colors.text.primary }}
          >
            추천 시술
          </h3>
          <RecommendedTreatments />
        </div>
      </main>

      {/* Bottom Navigation */}
      <BottomNav />
    </div>
  )
}

