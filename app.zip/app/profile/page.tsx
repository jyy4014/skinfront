'use client'

import { useRouter } from 'next/navigation'
import { createClient } from '@/app/lib/supabaseClient'
import { useAuth } from '@/app/lib/auth'
import { useUserProfile, useAnalysisHistory } from '@/app/lib/data'
import { ArrowLeft, User, Calendar, Mail, LogOut, Edit, Sparkles } from 'lucide-react'
import Link from 'next/link'
import BottomNav from '@/app/components/common/BottomNav'
import { LoadingSpinner, EmptyState } from '@/app/lib/ui'
import ProfileCompletionChart from '@/app/components/profile/ProfileCompletionChart'
import ProfileStats from '@/app/components/profile/ProfileStats'
import QuickActions from '@/app/components/profile/QuickActions'
import ProfileCompletionBanner from '@/app/components/profile/ProfileCompletionBanner'
import { calculateProfileCompletion } from '@/app/lib/utils/profileCompletion'
import { designTokens } from '@/app/styles/design-tokens'

export default function ProfilePage() {
  const router = useRouter()
  const supabase = createClient()
  const { user } = useAuth()
  const { data: userProfileData, isLoading: profileLoading } = useUserProfile()
  const { data: analyses, isLoading: analysesLoading } = useAnalysisHistory({
    filters: { limit: 10 },
  })

  const loading = profileLoading || analysesLoading
  const userProfile = userProfileData?.profile || {
    id: user?.id,
    email: user?.email,
    name: userProfileData?.user_metadata?.name || '',
  }

  const handleLogout = async () => {
    await supabase.auth.signOut()
    router.push('/auth/login')
  }

  if (!user) {
    router.push('/auth/login')
    return null
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <LoadingSpinner fullScreen message="로딩 중..." />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 via-pink-50 to-purple-50 pb-20">
      {/* Header - 모바일 앱 스타일 */}
      <header 
        className="bg-white/80 backdrop-blur-lg sticky top-0 z-40 safe-area-top border-b"
        style={{
          borderColor: designTokens.colors.border.subtle,
        }}
      >
        <div className="max-w-md mx-auto px-4 py-3 flex items-center gap-3">
          <Link
            href="/home"
            className="p-2 -ml-2 rounded-lg transition-colors"
            style={{ color: designTokens.colors.gray[600] }}
            onMouseEnter={(e) => {
              e.currentTarget.style.backgroundColor = designTokens.colors.gray[100]
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.backgroundColor = 'transparent'
            }}
          >
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <h1 
            className="text-xl font-bold"
            style={{ color: designTokens.colors.text.primary }}
          >
            마이페이지
          </h1>
        </div>
      </header>

      <main className="max-w-md mx-auto px-4 py-6 space-y-6">
        {/* 프로필 완성도 배너 */}
        <ProfileCompletionBanner />

        {/* 프로필 헤더 카드 */}
        <div 
          className="rounded-2xl shadow-lg p-6"
          style={{
            backgroundColor: designTokens.colors.surface.base,
            border: `1px solid ${designTokens.colors.border.subtle}`,
          }}
        >
          <div className="flex items-center gap-6">
            {/* 프로필 아바타 */}
            <div
              className="w-20 h-20 rounded-full flex items-center justify-center text-2xl font-bold text-white flex-shrink-0"
              style={{
                background: designTokens.gradients.primary,
              }}
            >
              {userProfile?.name?.[0]?.toUpperCase() || user?.email?.[0]?.toUpperCase() || 'U'}
            </div>

            {/* 프로필 정보 */}
            <div className="flex-1 min-w-0">
              <h2 
                className="text-xl font-bold mb-1"
                style={{ color: designTokens.colors.text.primary }}
              >
                {userProfile?.name || userProfile?.nickname || '사용자'}
              </h2>
              <p 
                className="text-sm truncate"
                style={{ color: designTokens.colors.text.secondary }}
              >
                {userProfile?.email || user?.email}
              </p>
              {userProfile?.nickname && userProfile.nickname !== userProfile.name && (
                <p 
                  className="text-xs mt-1"
                  style={{ color: designTokens.colors.text.tertiary }}
                >
                  @{userProfile.nickname}
                </p>
              )}
            </div>

            {/* 프로필 완성도 차트 */}
            <ProfileCompletionChart
              profile={userProfile}
              size={80}
              showDetails={false}
            />
          </div>
        </div>

        {/* 통계 카드 */}
        {user?.id && <ProfileStats userId={user.id} />}

        {/* 빠른 액션 */}
        <div 
          className="rounded-2xl shadow-lg p-6"
          style={{
            backgroundColor: designTokens.colors.surface.base,
            border: `1px solid ${designTokens.colors.border.subtle}`,
          }}
        >
          <h3 
            className="text-lg font-semibold mb-4 flex items-center gap-2"
            style={{ color: designTokens.colors.text.primary }}
          >
            <Sparkles className="w-5 h-5" style={{ color: designTokens.colors.primary[600] }} />
            빠른 액션
          </h3>
          <QuickActions />
        </div>

        {/* 프로필 정보 상세 */}
        <div 
          className="rounded-2xl shadow-lg p-6 space-y-6"
          style={{
            backgroundColor: designTokens.colors.surface.base,
            border: `1px solid ${designTokens.colors.border.subtle}`,
          }}
        >
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h2 
                className="text-lg font-semibold"
                style={{ color: designTokens.colors.text.primary }}
              >
                프로필 정보
              </h2>
              <Link
                href="/profile/edit"
                className="flex items-center gap-2 px-4 py-2 text-white rounded-lg font-semibold hover:shadow-lg transition-all text-sm"
                style={{
                  background: designTokens.gradients.primary,
                }}
              >
                <Edit className="w-4 h-4" />
                수정
              </Link>
            </div>
            <div 
              className="rounded-xl p-5 space-y-4"
              style={{
                backgroundColor: designTokens.colors.surface.muted,
              }}
            >
              <div className="flex items-center gap-3">
                <User 
                  className="w-5 h-5" 
                  style={{ color: designTokens.colors.gray[600] }} 
                />
                <div>
                  <p 
                    className="text-sm"
                    style={{ color: designTokens.colors.text.secondary }}
                  >
                    이름
                  </p>
                  <p 
                    className="text-lg font-semibold"
                    style={{ color: designTokens.colors.text.primary }}
                  >
                    {userProfile?.name || '미설정'}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Mail 
                  className="w-5 h-5" 
                  style={{ color: designTokens.colors.gray[600] }} 
                />
                <div>
                  <p 
                    className="text-sm"
                    style={{ color: designTokens.colors.text.secondary }}
                  >
                    이메일
                  </p>
                  <p 
                    className="text-lg font-semibold"
                    style={{ color: designTokens.colors.text.primary }}
                  >
                    {userProfile?.email || user?.email}
                  </p>
                </div>
              </div>
              {userProfile?.birth_date && (
                <div className="flex items-center gap-3">
                  <Calendar 
                    className="w-5 h-5" 
                    style={{ color: designTokens.colors.gray[600] }} 
                  />
                  <div>
                    <p 
                      className="text-sm"
                      style={{ color: designTokens.colors.text.secondary }}
                    >
                      생년월일
                    </p>
                    <p 
                      className="text-lg font-semibold"
                      style={{ color: designTokens.colors.text.primary }}
                    >
                      {new Date(userProfile.birth_date).toLocaleDateString(
                        'ko-KR'
                      )}
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* 개인정보 처리 안내 */}
          <div 
            className="border rounded-xl p-4"
            style={{
              backgroundColor: designTokens.colors.primary[50],
              borderColor: designTokens.colors.primary[200],
            }}
          >
            <h3 
              className="text-sm font-semibold mb-2"
              style={{ color: designTokens.colors.primary[900] }}
            >
              개인정보 처리 안내
            </h3>
            <p 
              className="text-xs leading-relaxed"
              style={{ color: designTokens.colors.primary[800] }}
            >
              사용자의 이미지와 분석 데이터는 익명화되어 저장되며, AI 모델 학습용으로 재사용되지 않습니다. 이미지는 사용자가 삭제 요청 시 즉시 파기됩니다.
            </p>
          </div>

          {/* 분석 기록 */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h2 
                className="text-lg font-semibold"
                style={{ color: designTokens.colors.text.primary }}
              >
                최근 분석 기록
              </h2>
              {analyses && analyses.length > 0 && (
                <Link
                  href="/history"
                  className="text-sm font-medium"
                  style={{ color: designTokens.colors.primary[600] }}
                >
                  전체 보기 →
                </Link>
              )}
            </div>
            {!analyses || analyses.length === 0 ? (
              <EmptyState
                icon="history"
                message="아직 분석 기록이 없습니다."
                description="첫 분석을 시작해보세요."
                action={
                  <Link
                    href="/analyze"
                    className="inline-block px-6 py-3 text-white rounded-lg font-semibold hover:shadow-lg transition-all"
                    style={{
                      background: designTokens.gradients.primary,
                    }}
                  >
                    첫 분석 시작하기
                  </Link>
                }
              />
            ) : (
              <div className="space-y-4">
                {analyses?.map((analysis: any) => (
                  <Link
                    key={analysis.id}
                    href={`/analysis/${analysis.id}`}
                    className="block rounded-xl p-4 transition-colors"
                    style={{
                      backgroundColor: designTokens.colors.surface.muted,
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.backgroundColor = designTokens.colors.gray[100]
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.backgroundColor = designTokens.colors.surface.muted
                    }}
                  >
                    <div className="flex gap-4">
                      <div className="w-20 h-20 rounded-lg overflow-hidden bg-gray-200 flex-shrink-0">
                        <img
                          src={analysis.image_url}
                          alt="분석 이미지"
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div className="flex-1">
                        <p className="text-gray-700 mb-2 line-clamp-2">
                          {analysis.result_summary}
                        </p>
                        <p className="text-sm text-gray-500">
                          {new Date(analysis.created_at).toLocaleDateString(
                            'ko-KR',
                            {
                              year: 'numeric',
                              month: 'long',
                              day: 'numeric',
                            }
                          )}
                        </p>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </div>

          {/* 로그아웃 */}
          <div 
            className="pt-6 border-t"
            style={{ borderColor: designTokens.colors.border.subtle }}
          >
            <button
              onClick={handleLogout}
              className="w-full flex items-center justify-center gap-2 py-3 border-2 rounded-lg font-semibold transition-colors"
              style={{
                borderColor: designTokens.colors.danger[200],
                color: designTokens.colors.danger[600],
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.backgroundColor = designTokens.colors.danger[50]
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.backgroundColor = 'transparent'
              }}
            >
              <LogOut className="w-5 h-5" />
              로그아웃
            </button>
          </div>
        </div>
      </main>

      {/* Bottom Navigation */}
      <BottomNav />
    </div>
  )
}

